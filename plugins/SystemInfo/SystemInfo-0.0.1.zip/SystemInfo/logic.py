import sys
import os

_parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

import time
import json
import psutil
import platform
import wmi
import socket
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QTextBrowser, QHBoxLayout
from PySide6.QtCore import Qt
from plugin_core import BasePlugin
PLUGIN_API_VERSION = "2.0"  # kontrakt wtyczka<->Loader (PySide6), patrz KONTRAKT_WTYCZEK.md

def get_size(bytes_val, suffix="B"):
    if not bytes_val: return "0B"
    try: bytes_val = float(bytes_val)
    except: return "0B"  # wartość nie jest liczbą — pokazujemy 0B
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if bytes_val < factor: return f"{bytes_val:.2f}{unit}{suffix}"
        bytes_val /= factor

# --- Odczyt danych sprzętowych przez WMI (COM), zamiast subprocess+powershell ---
# Sandbox blokuje subprocess (patrz sandbox_bootstrap.py) — moduł 'wmi' (pywin32/COM)
# jest jedynym dozwolonym sposobem odpytania Win32_* bez wykonywania procesu.
# Wzorzec identyczny jak w plugins/PowerMonitor/logic.py (wmi.WMI(...) bez jawnego
# pythoncom.CoInitialize() — działa tam w produkcji, więc powielamy 1:1).

def get_cpu_info():
    try:
        cpus = wmi.WMI().Win32_Processor()
        return cpus[0].Name.strip() if cpus and cpus[0].Name else platform.processor()
    except Exception:  # WMI niedostępne — wracamy do platform.processor()
        return platform.processor()

def get_gpu_info():
    gpus = []
    try:
        for g in wmi.WMI().Win32_VideoController():
            if g.Name: gpus.append(g.Name.strip())
    except Exception: pass  # WMI niedostępne albo odmowa dostępu — brak kart graficznych w raporcie
    return gpus if gpus else ["Brak danych GPU"]

def get_ram_sticks():
    sticks = []
    ddr_map = {'20': 'DDR', '21': 'DDR2', '24': 'DDR3', '26': 'DDR4', '30': 'LPDDR4', '34': 'DDR5', '35': 'LPDDR5'}
    try:
        for m in wmi.WMI().Win32_PhysicalMemory():
            manufacturer = (m.Manufacturer or "").strip()
            part = (m.PartNumber or "").strip()
            speed = m.Speed if m.Speed is not None else "?"
            capacity = m.Capacity if m.Capacity is not None else 0
            mem_type = str(m.SMBIOSMemoryType) if m.SMBIOSMemoryType is not None else ""
            sticks.append(f"{manufacturer} {part} ({get_size(capacity)}) @ {speed}MHz [{ddr_map.get(mem_type, '??')}]")
    except Exception: pass  # WMI niedostępne — brak modułów RAM w raporcie
    return sticks

def get_net_hw_map():
    h_map = {}
    try:
        for a in wmi.WMI().Win32_NetworkAdapter():
            if a.NetConnectionID:
                h_map[a.NetConnectionID] = a.Name
    except Exception: pass  # WMI niedostępne — brak nazw sprzętowych kart sieciowych
    return h_map

def get_disk_info():
    disks = []
    try:
        for d in wmi.WMI().Win32_DiskDrive():
            model = (d.Model or "").strip()
            size = d.Size if d.Size is not None else 0
            disks.append((model, size))
    except Exception: pass  # WMI niedostępne — brak dysków fizycznych w raporcie
    return disks

class SystemInfoWidget(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        # RUNDA 5 (2026-08-18, patrz PLAN_ROZWOJU_2026-08-12.md sekcja 11) —
        # QGraphicsProxyWidget.setWidget() sam w sobie realizuje ten widget
        # jako chwilowe, prawdziwe okno przy embedowaniu, niezależnie od flag.
        # Skoro nie da się zapobiec powstaniu, sprawiamy że jest niewidoczne —
        # od razu poza ekranem i 1px (workspace.py robi to samo tuż przed setWidget()).
        from config import is_ghost_flash_debug_enabled
        if not is_ghost_flash_debug_enabled():
            self.setGeometry(-32000, -32000, 1, 1)
            self.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
            self.setWindowFlags(Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint)
        self.setObjectName("MainFrame")
        self.setStyleSheet("""
            #MainFrame { background: transparent; border: none; }
            QLabel { color: #c9d1d9; font-family: 'Segoe UI'; background: transparent; }
            #TitleLabel { color: #58a6ff; font-weight: bold; font-size: 14px; }
            QTextBrowser {
                background-color: #0d1117; border: 1px solid #30363d;
                border-radius: 6px; color: #8b949e; font-family: 'Consolas', monospace; font-size: 10px;
            }
            QScrollBar:vertical { border: none; background: transparent; width: 6px; margin: 0px; }
            QScrollBar::handle:vertical { background: #21262d; min-height: 20px; border-radius: 3px; }
            QScrollBar::handle:vertical:hover { background: #58a6ff; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { border: none; background: none; height: 0px; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
        """)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 25, 15, 15)
        h = QHBoxLayout()
        self.title = QLabel("PEŁNA SPECYFIKACJA PC")
        self.title.setObjectName("TitleLabel")
        h.addWidget(self.title)
        layout.addLayout(h)
        self.browser = QTextBrowser()
        self.browser.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        layout.addWidget(self.browser)
        self.browser.setText("Skanowanie systemu... Czekaj...")

    def update_data(self, data_str):
        try:
            data = json.loads(data_str)
            if data.get("type") == "heartbeat": return
            if "text" in data: self.browser.setText(data["text"])
        except Exception: pass  # nieczytelna lub nieoczekiwana linia z backendu nie może wywrócić widżetu — czekamy na kolejną aktualizację

class SystemInfoPlugin(BasePlugin):
    @staticmethod
    def get_config():
        return {
            "name": "Full System Info",
            "plugin_id": "full_system_info",
            "category": "System",
            "width": 4,
            "height": 5,
            "widget_class": SystemInfoWidget
        }

    def init_ui(self):
        return SystemInfoWidget()

    def collect_info(self):
        try:
            u = platform.uname()
            lines = []
            lines.append(f"[ SYSTEM ]\nOS: {u.system} {u.release}\nNode: {u.node}\nArch: {u.machine}")
            lines.append(f"\n[ PROCESOR ]\n{get_cpu_info()}\nCores: {psutil.cpu_count(logical=False)}F / {psutil.cpu_count(logical=True)}W")
            mem = psutil.virtual_memory()
            lines.append(f"\n[ PAMIĘĆ RAM ]\nTotal: {get_size(mem.total)} (Użyte: {mem.percent}%)")
            for s in get_ram_sticks(): lines.append(f"• {s}")
            lines.append(f"\n[ KARTY GRAFICZNE ]")
            for g in get_gpu_info(): lines.append(f"• {g}")
            lines.append(f"\n[ DYSKI FIZYCZNE ]")
            for model, size in get_disk_info():
                lines.append(f"• {model} ({get_size(size)})")
            lines.append(f"\n[ PARTYĆJE LOGICZNE ]")
            for part in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    lines.append(f"• {part.device} [{part.fstype}] {get_size(usage.total)} (Wolne: {get_size(usage.free)})")
                except: continue  # partycja bez nośnika (np. napęd optyczny) — pomijamy
            lines.append(f"\n[ SIEĆ ]")
            hw = get_net_hw_map()
            for name, addrs in psutil.net_if_addrs().items():
                ip = next((a.address for a in addrs if a.family == socket.AF_INET), "Brak IP")
                lines.append(f"• {name} ({hw.get(name, '')})\n  IP: {ip}")
            return "\n".join(lines)
        except Exception as e:  # błąd trafia do tekstu raportu pokazanego w widżecie
            return f"Błąd: {str(e)}"

    def run_backend(self):
        print(f"PID:{os.getpid()}", flush=True)

        while True:
            text = self.collect_info()
            self.send_to_gui({"text": text})
            time.sleep(60)

def get_config(): return SystemInfoPlugin.get_config()

if __name__ == "__main__":
    if "--backend" in sys.argv:
        SystemInfoPlugin().run_backend()
